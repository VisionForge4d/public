---

## title: 📘 README.md (Vault Root)

# 🏫 Schoolhouse Vault — README

Welcome to the Schoolhouse Vault. This is a modular toolkit designed for builders, creators, and AI operators who want to **move fast, build clearly, and think like systems architects.**

> _“This isn’t a note vault. It’s a forge.”_

## 🔧 What's Inside

- `schoolhouse-onboarding.md` → Start here. The core guide to prompt writing, vault usage, and GPT tactics.
    
- `schoolhouse-manifest.md` → File index of all included modules.
    
- `modules/` → Learning packs + system tutorials
    
- `templates/` → Prompt frameworks + logs
    
- `rituals/` → Behavioral tools + clarity resets
    
- `outputs/` → Your work goes here
    

## 🧠 Philosophy

This vault is part of the **Schoolhouse Method**, a way of learning prompt design, AI literacy, and builder UX without fluff.

You’re not here to organize. You’re here to build, test, and archive results.

## ✅ First Step

Open `schoolhouse-onboarding.md` → follow the Quick Start.  
Then create your first file in `outputs/` and start building.

> _“Name what matters. Save what works. Keep building.”_

---

## title: 📍 system-map.md

# 📍 System Map — Schoolhouse Vault

A living index of your files, projects, and modules. Start linking as your vault expands.

## 🧱 Key Docs

- [[schoolhouse-onboarding.md]]
    
- [[schoolhouse-manifest.md]]
    
- [[VisionForge/VF1.0/Readme]]
    

## 📚 Modules

- [[prompt-writing-basics.md]]
    
- [[modular-stack-example.md]]
    
- [[Obsidian Catch-Up Module.md]]
    
- [[Obsidian Interface Primer.md]]
    

## 🧰 Templates

- [[output-log-template.md]]
    
- [[debugger-template.md]]
    

## 🔄 Rituals

- [[ritual-reset.md]]
    

## 📝 Outputs

> Add links to your custom prompt files below:

- [[obsidian-practice-note.md]]
    
- [[first-build-[your-prompt].md]]
    

---

## title: 🗓️ first-week.md

# 🗓️ First Week: Builder Onboarding Tracker

Use this as a guide + ritual log for your first 7 days in the vault.

## Day 1: Set Up

-  Install Obsidian + create `schoolhouse-vault`
    
-  Read `schoolhouse-onboarding.md`
    
-  Write your first output in `/outputs/`
    

## Day 2: Prompt Fluency

-  Study `prompt-writing-basics.md`
    
-  Modify + save your first modular prompt
    

## Day 3: Vault Motion

-  Link one file to another (`[[ ]]`)
    
-  Add tags + metadata to a file
    

## Day 4: Run a Ritual

-  Use `ritual-reset.md` when friction hits
    
-  Journal what shifted
    

## Day 5–6: Expand

-  Clone and modify a template (`debugger`, `log`, etc.)
    
-  Try a 3-part modular stack of your own
    

## Day 7: Reflect

-  Review outputs folder
    
-  Add links to `system-map.md`
    
-  Archive one working prompt for reuse
    

> “Build daily. Even 15 minutes compounds.”

---

Drop all finished prompts into `outputs/`, and tag them `#first-build` to track your evolution.

---